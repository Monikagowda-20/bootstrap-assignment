 
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import BodyComp from './components/body.component';
import CaroselComp from './components/carousel.component';
import FooterComp from './components/footer.component';
import HeaderComp from './components/header.component';
import HeaderComp1 from './components/header1.component';



class MainApp extends Component{
  render(){
       
        return <>
        <div className="container-fluid">
              
        <HeaderComp/><br/>
        <CaroselComp/>
        <HeaderComp1/>

       <BodyComp/><br/>
       <FooterComp/>
       

              </div>
              </>
  }
};

ReactDOM.render(<MainApp/>,  document.getElementById('root') );