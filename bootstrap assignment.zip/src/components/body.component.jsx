import { Component } from "react";
import batman1 from './bat1_tn.jpg';
import batman2 from './bat2_tn.jpg';
import antman from './antman.jpg';
 
class BodyComp extends Component{
   
    render(){
      return <>
<div className="row">
      <div className="col-7 mt-5 text-center text-muted text-justify">
          <h1>First featurette heading. It’ll blow your mind.</h1>
            <h5>Some great placeholder content for the first featurette here. Imagine some exciting prose here.</h5>
      </div>
       <div className="col-5">
          <img src={batman1} width="400" height="400"/>
      </div>
</div> 
      <br/><br/><hr/><br/>
<div className="row">
      <div className="col-5">
           <img src={batman2}  width="400" height="400"/>
      </div>
      <div className="col-7 mt-5 text-center text-muted">
            <h1>Oh yeah, it’s that good. See for yourself.</h1>
            <h5>Another featurette? Of course. More placeholder content here to give you an idea of how this layout would work with some actual real-world content in place.</h5>
      </div>
</div>
      <br/><br/> <hr/><br/>
 <div className="row">
      <div className="col-7 mt-5 text-center text-muted">
          <h1>And lastly, this one. Checkmate.</h1>
         <h5>And yes, this is the last block of representative placeholder content. Again, not really intended to be actually read, simply here to give you a better view of what this would look like with some actual content. Your content..</h5>
      </div>
    <div className="col-5">
         <img src={antman}  width="400" height="400"/>
    </div>
 </div>
      <br/><br/><hr/><br/>
</>
    }
}
export default BodyComp;