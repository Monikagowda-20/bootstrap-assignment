import { Component } from "react";
 
class FooterComp extends Component{
   
    render(){
      return <>
      <div className="row">
      <div className="col-10 text-left">
      &copy;2017-2021 Company,Inc <a href="#" class="text-reset text-primary">Privacy .Terms</a>
      </div>
      <div className="col-2 text-right">
      <a href="#" class="text-reset text-secondary">Back To Top</a>
      </div>
      </div>
      <br/>
      </>
    }
}
export default FooterComp;