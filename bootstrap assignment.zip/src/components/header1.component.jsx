import { Component } from "react";
import black from './blackpanther.jpg';
import widow from './blackwidow.jpg';
import captain from './captainamerica.jpg';

 
class HeaderComp1 extends Component{
   
    render(){
        return<>
      
        <div className="row justify-content-between">
        <div className="col-4">
     <img src={black} className="rounded-circle"/>
     <h1>Heading</h1>
     <p>Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>

        </div>
        <div className="col-4">
        <img src={widow} className="  rounded-circle" />
     <h1 className="text-justify">Heading</h1>
     <p className="text-justify">Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
        </div>
        <div className="col-4">
        <img src={captain} className="rounded-circle" />
     <h1>Heading</h1>
     <p>Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
        </div>
        </div>
    
        </>
    }
}
export default HeaderComp1;